package model;

import java.awt.Color;


/**
 * Represents an Oval shape, extends AShape.
 */
public class Oval extends AShape {

  /**
   * Uses same constructor as the AShape class, there are no new fields for an Oval.
   * @param name the name of the shape
   * @param pos the starting position of the shape
   * @param color the starting color of the shape
   * @param size the starting size of the shape.
   */
  public Oval(String name, Coordinate pos, Color color, Size size,
              int startOfLife, int endOfLife) {
    super(name, size, pos, color, startOfLife, endOfLife);

  }

  /**
   * Overrides the toString method on a shape in order to output a string that describes all of the
   * information about the state of an oval.
   * @return
   */
  @Override
  public String toString() {
    return "Oval " + this.name + " x:" + this.position.getX() + " y:" + this.position.getY()
            + " w:" +
            this.size.getWidth() + " h:" + this.size.getHeight() + " r:" +
            this.color.getRed() + " g:" + this.color.getGreen() + " b:" +
            this.color.getBlue();
  }

  @Override
  public IShape copyShape() {
    return new Oval(name, position, color, size, startOfLife, endOfLife);
  }

  @Override
  public String getTypeOfShape() {
    return "ellipse";
  }

  @Override
  public String svgTagForShape() {
    return null;
  }
}
