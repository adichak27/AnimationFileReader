package model;

import java.awt.Color;


/**
 * Represents a rectangle that extends AShape.
 */
public class Rectangle extends AShape {

  /**
   * Creates a rectangle using the same parameters as the AShape abstract class.
   * @param name the name of the shape.
   * @param pos the position of the shape.
   * @param color the color of the shape.
   * @param size the size of the shape.
   */
  public Rectangle(String name, Coordinate pos, Color color, Size size,
                   int startOfLife, int endOfLife) {
    super(name, size, pos, color, startOfLife, endOfLife);

  }


  /**
   * Overrides the toString method in order to return a textual description of the shape in its
   * state.
   * @return textual description of rectangle.
   */
  @Override
  public String toString() {
    return "Rectangle " + this.name + " x:" + this.position.getX() + " y:" + this.position.getY()
            + " w:" +
            this.size.getWidth() + " h:" + this.size.getHeight() + " r:" +
            this.color.getRed() + " g:" + this.color.getGreen() + " b:" +
            this.color.getBlue();
  }

  @Override
  public IShape copyShape() {
    return new Rectangle(name, position, color, size, startOfLife, endOfLife);
  }

  @Override
  public String getTypeOfShape() {
    return "rect";
  }

  @Override
  public String svgTagForShape() {
    return null;
  }
}

