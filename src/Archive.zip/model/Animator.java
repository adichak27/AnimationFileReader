package model;

import java.util.List;



/**
 * Represents the Interface for an Animator. An Animator allows a user to
 */
public interface Animator {

  /**
   * Outputs the state of this Animator as a string. The state includes the starting state of each
   * shape, followed by an ordered listing of their transformations,
   * how they alter the shape, and the intervals that they occur over.
   * @return A String that describes the transformations that occur on states over an animation.
   */

  public String outputState();

  /**
   * adds a shape to this Animator if the shape does not already exist.
   * @param s the shape that is being added
   */
  public void addShape(IShape s);


  /**
   * Returns a list of all of the shapes in this Animator.
   * @return a list of the shapes in this animator
   */
  public List<IShape> getShapes();

  /**
   * Removes the given shape from this animator, and removes all of the transformations associated
   * with the given shape from the animator.
   * @param s the shape that is being removed from the animator.
   */
  public void removeShape(IShape s);

  /**
   * Adds a transformation to this animator, as well as to the shape that the transformation
   * will be performed on, only if the transfomration is able to be added.
   * The transformation can only be added if the transformation isnt both of a conflicting type,
   * and an overlapping interval, and if it does not affect the adjacency of transformations. Also
   * transformations must be added in order.
   * @param t the transformation that is attempting to be added
   */
  public void addTransformation(Transformation t);

  /**
   * Removes the given Transformation from this animators list of transformations, as well
   * as from the list of transformations that the shape stores.
   * @param t The transformation that is being removed
   */
  public void removeTransformation(Transformation t);

  /**
   * gets all of the transformations that will occur over the animation.
   * @return a list of all transformations.
   */

  public List<Transformation> getTransformations();


  /**
   * gets the last tick of this animator. the last tick is determined by looking through each shapes
   * transformationOverInterval field and determining the highest ending interval value. After,
   * each shapes highest value is compared, and that is the last tick.
   * @return the last tick of this animator.
   */
  public int getLastTick();

  /**
   * returns a copy of a list of shapes contained in this animator, with the states of the shapes
   * reflecting the state that the shape will be in at the specified tick. will use the
   * getShapeAtTick() method that will be implemented later. There is a stub located in the
   * EasyAnimator class for this method. With this method, the state of all shapes in the animator
   * can be retrieved at any tick, making this extremely useful for the view and controller.
   * @param tick The tick that the states are specified for.
   * @return a List of the copy of every shape in the animator, with each shapes state correctly
   *         reflecting the state at the given tick.
   */
  public List<IShape> getShapesAtTick(int tick);


  //added assignment 5
  public void setCanvasDimensions(int x, int y, int width, int height);

  //added assignment 5
  public IShape getShapeWithName(String name);


  //added assignment 5
  public int[] getCanvasDimensions();
}
