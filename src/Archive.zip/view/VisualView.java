package view;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import model.Animator;
import model.IShape;

public class VisualView extends AView {
 private final AnimatorPanel panel;


 public VisualView(Animator model, int tempo) {
   super(model, tempo);
   this.panel = new AnimatorPanel();


   //jframe smaller than preffered size when using scorlling
   // this.setSize();
   //preferred size using canvas?
   panel.setPreferredSize(new Dimension(500, 500));
   JScrollPane pane = new JScrollPane(panel);
   pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
   //do we need to have vertical bar too
   pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
   //pane.setBounds(0, 0, 500, 500);

   this.add(pane, BorderLayout.CENTER);

   this.pack();


 }


 public void makeVisible() {
   this.setVisible(true);
 }

  @Override
  public void render(int tick) {
    panel.drawView((ArrayList<IShape>) model.getShapesAtTick(tick));
  }

  @Override
  public int getTempo() {
    return this.tempo;
  }

  @Override
  public void writeOut(String fileName) throws IOException {
    throw new UnsupportedOperationException("No write out for visual view");
    }

  }

