package view;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import model.Animator;
import model.IShape;
import model.Transformation;

public class TextView extends AView {
 private final StringBuilder output;

 public TextView(Animator model, int tempo) {
   super(model, tempo);
   this.output = new StringBuilder();
 }




 //pass tick
  @Override
  public void render(int tick) {
   List<IShape> shapes = model.getShapes();
    for (IShape s : shapes) {
      String createString = "Create: " + s.toString() + "; Appears at time " +
              tickToSecond(s.getStartOfLife()) + "\n";
      output.append(createString);
      ArrayList<Transformation> transformations = s.getAllTransformations();
      for (Transformation t : transformations) {
        output.append("From second "  + tickToSecond(t.getInterval().getStarting()) + " to " +
                tickToSecond(t.getInterval().getEnding()) +  ", ");
        output.append(t.toString() + "\n");
      }
      output.append("Disappears at time " + tickToSecond(s.getEndOfLife()));
      output.append("\n");

    }
  }

  @Override
  public int getTempo() {
    return this.tempo;
  }


  /**
   * converts a given tick to its equal second, depending on the tempo of this view.
   * @param tick the tick that is being converted to seconds
   * @return the given tick in seconds.
   */
  //goes in controller if tempo is in controller and not here
  private double tickToSecond(int tick) {
   return (double) tick / tempo;
  }

  @Override
  public void writeOut(String fileName) throws IOException {
    String outputView = output.toString();

    try {
      FileWriter fileWriter = new FileWriter(fileName);
      fileWriter.write(outputView);
      fileWriter.close();
    } catch (IOException ioe) {
      throw new IOException("Text file writing operation failed.");
    }
  }

  @Override
  public void makeVisible() {
    throw new UnsupportedOperationException("cannot make text view visible");
  }

}
