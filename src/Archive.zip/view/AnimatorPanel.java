package view;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

import javax.swing.*;

import model.IShape;
import model.Oval;
import model.Rectangle;

public class AnimatorPanel extends JPanel {
  private  ArrayList<IShape> shapes;


  public AnimatorPanel() {
    this.shapes = null;
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    //affine transformation???
    //maybe set background
    if (shapes != null) {
      Graphics2D graphics = (Graphics2D) g;
      //dont need this
     // AffineTransform affineTransform = graphics.getTransform();
      for (IShape s : shapes) {
        int x = s.getLocation().getX();
        int y = s.getLocation().getY();
        int width =  (int) Math.round(s.getWidth());
        int height = (int) Math.round(s.getHeight());
        Color c = s.getColor();
        if (s instanceof Rectangle) {
          graphics.setColor(c);
          graphics.fillRect(x, y, width, height);
          graphics.drawRect(x, y, width, height);
        } else if (s instanceof Oval) {
          graphics.setColor(c);
          graphics.fillOval(x, y, width, height);
          graphics.drawOval(x, y, width, height);
        }
      }
      //graphics.setTransform(affineTransform);
    }
  }

  /**
   * sets the shapes in this panel to the list of shapes given, and then repaints
   * the panel using those shapes.
   * @param shapes the shapes that will be painted.
   */
  public void drawView(ArrayList<IShape> shapes) {
    this.shapes = shapes;
    repaint();
  }

}
