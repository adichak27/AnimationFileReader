package view;

import model.Animator;

public class FactoryView {

  public IView createView(String type, Animator model, int tempo) {
    switch (type) {
      case "VisualView":
        return new VisualView(model, tempo);
      case "TextView":
        return new TextView(model, tempo);
      case "SVGView":
        return new SVGView(model, tempo);
      default: throw new IllegalArgumentException("should never happen");
    }

  }
}
