package view;

import java.io.IOException;

public interface IView {


  /**
   * renders the state of the animators model.
   */
  public void render(int tick);



  /**
   * gets the tempo that this view is using.
   * @return the tempo as an integer
   */
  public int getTempo();

  public void writeOut(String fileName) throws IOException;

  public void makeVisible();

}
