package view;

import javax.swing.*;

import model.Animator;

//should we extend JFrame here?
abstract public class AView extends JFrame implements IView {
  protected final Animator model;
  protected final int tempo;


  public AView(Animator model, int tempo) {
    if (model == null) {
      throw new IllegalArgumentException("model cannot be null");
    } else {
      this.model = model;
      this.tempo = tempo;
    }
  }



  abstract public void render(int tick);

  public int getTempo() {
    return this.tempo;
  }
}
