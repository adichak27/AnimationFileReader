package view;

import model.Animator;

public class SVGView extends AView{
  private StringBuilder out;


  public SVGView(Animator model, int tempo) {
    super(model, tempo);
    this.out = new StringBuilder();
  }


  @Override
  public void render(int tick) {
    //renders the canvas screen
    out.append("<svg width=\"" + model.getCanvasDimensions()[3] +  "\" height=\""
            + model.getCanvasDimensions()[4] + "\" version = \"1.1\" \n"
            + "   xmlns=\"http://www.w3.org/2000/svg\">\n");
  }
}
